-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2024 at 07:10 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `payrollsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(193) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(193) NOT NULL,
  `owner` varchar(193) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `department` varchar(193) NOT NULL,
  `EmployeeID` varchar(193) NOT NULL,
  `comment` varchar(193) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `department`, `EmployeeID`, `comment`, `created_at`, `updated_at`) VALUES
(1, 'hr', '200084704171', NULL, '2024-05-02 00:27:40', '2024-05-02 00:27:40'),
(2, 'packing', '200084704171', NULL, '2024-05-02 02:08:08', '2024-05-02 02:08:08'),
(3, 'operator', '0621', NULL, '2024-05-29 11:03:13', '2024-05-29 11:03:13'),
(4, 'hr', '20008470', NULL, '2024-05-29 11:17:33', '2024-05-29 11:17:33'),
(5, 'hr', '20008470', NULL, '2024-05-29 11:24:33', '2024-05-29 11:24:33'),
(6, 'operator', '5896', 'jb jhvbjhsd', '2024-05-29 11:24:49', '2024-05-29 11:24:49'),
(7, 'operator', '5896', 'jb jhvbjhsd', '2024-05-29 11:25:42', '2024-05-29 11:25:42'),
(8, 'operator', '5896', 'jb jhvbjhsd', '2024-05-29 11:27:57', '2024-05-29 11:27:57'),
(9, 'operator', '5846', 'jfbwegdwekurfy', '2024-05-29 11:28:07', '2024-05-29 11:28:07'),
(10, 'operator', '5846', 'jfbwegdwekurfy', '2024-05-29 11:28:52', '2024-05-29 11:28:52'),
(11, 'hr', '0627', 'ouegdhjvcwjeydtwefd', '2024-05-29 11:29:05', '2024-05-29 11:29:05');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(193) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(193) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(193) NOT NULL,
  `name` varchar(193) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(193) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2024_04_30_082546_create_signups_table', 2),
(5, '2024_05_01_065040_create_profiles_table', 3),
(6, '2024_05_01_084535_create_employees_table', 4),
(7, '2024_05_01_131321_create_profiles_table', 5),
(8, '2024_05_01_165549_create_contacts_table', 6),
(9, '2024_05_01_181648_create_contacts_table', 7),
(10, '2024_05_02_052122_create_contacts_table', 8),
(11, '2024_05_02_054505_create_contacts_table', 9),
(12, '2024_05_02_055627_create_contacts_table', 10),
(13, '2024_05_28_123625_create_salaries_table', 11),
(14, '2024_05_28_125830_create_salaries_table', 12),
(15, '2024_05_28_133212_create_salaries_table', 13),
(16, '2024_05_29_094339_create_oldpays_table', 14);

-- --------------------------------------------------------

--
-- Table structure for table `oldpays`
--

CREATE TABLE `oldpays` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `month` varchar(193) NOT NULL,
  `fullname` varchar(193) NOT NULL,
  `EmployeeID` varchar(193) NOT NULL,
  `address` varchar(193) NOT NULL,
  `department` varchar(193) NOT NULL,
  `basicSalary` varchar(193) NOT NULL,
  `hourlyPay` varchar(193) NOT NULL,
  `workDays` varchar(193) NOT NULL,
  `attendancePay` varchar(193) NOT NULL,
  `overtimePay` varchar(193) NOT NULL,
  `bonus` varchar(193) NOT NULL,
  `loans` varchar(193) NOT NULL,
  `noPay` varchar(193) NOT NULL,
  `epf` varchar(193) NOT NULL,
  `totalPay` varchar(193) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oldpays`
--

INSERT INTO `oldpays` (`id`, `created_at`, `updated_at`, `month`, `fullname`, `EmployeeID`, `address`, `department`, `basicSalary`, `hourlyPay`, `workDays`, `attendancePay`, `overtimePay`, `bonus`, `loans`, `noPay`, `epf`, `totalPay`) VALUES
(1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'January', 'N.Sureka Sandaruwani', '19918420318', 'Gallegama, Ingiriya', 'HR', '40000', '200', '26', '3000', '7000', '2500', 'none', 'none', '2000', '52000'),
(2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'January', 'Kavishka Sandaruwani', '20067', 'dumbara, ellagawa', 'MO', '50000', '250', '25', 'none', '3000', 'none', 'none', '1000', '2000', '50 000'),
(3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'February', 'Kavishka Sandaruwani', '20067', 'dumbara, ellagawa', 'MO', '50 000', '200', '26', '3000', '7000', '2500', 'none', 'none', '2000', '60 500');

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(193) NOT NULL,
  `token` varchar(193) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `fullname` varchar(193) NOT NULL,
  `EmployeeID` varchar(193) NOT NULL,
  `birthday` varchar(193) NOT NULL,
  `department` varchar(193) NOT NULL,
  `starting_date` varchar(193) DEFAULT NULL,
  `gender` varchar(193) NOT NULL,
  `phone` varchar(193) NOT NULL,
  `address` varchar(193) NOT NULL,
  `email` varchar(193) NOT NULL,
  `passw` varchar(193) NOT NULL,
  `bank` varchar(193) NOT NULL,
  `acc_type` varchar(193) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`fullname`, `EmployeeID`, `birthday`, `department`, `starting_date`, `gender`, `phone`, `address`, `email`, `passw`, `bank`, `acc_type`, `created_at`, `updated_at`) VALUES
('Kavishka Sandaruwani', '200084704171', '1996-12-12', 'hr', '2023-02-05', 'female', '0756333273', 'Newtown, Rathnapura', 'ksandaruwani36@gmail.com', '0412', '200300584316', 'Master card', '2024-05-01 08:35:22', '2024-05-01 08:35:22'),
('D. Malindu Dananjaya', '199685742589', '1996-05-06', 'operator', '2020-08-09', 'male', '07405460524', 'Idangoda,Kiriella', 'malindu54@gmail.com', '6532ma', '120365014789', 'Visa', '2024-05-01 13:01:33', '2024-05-01 13:01:33'),
('N. Sureka Sandaruwani', '199184203181', '1991-03-01', 'hr', '2023-12-12', 'female', '0705024327', 'Gallegama, Ingiriya', 'sureakas91@gmail.com', '0530', '300100345762', 'Credit card', '2024-05-26 03:32:36', '2024-05-26 03:32:36');

-- --------------------------------------------------------

--
-- Table structure for table `salaries`
--

CREATE TABLE `salaries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `fullname` varchar(193) NOT NULL,
  `EmployeeID` varchar(193) NOT NULL,
  `address` varchar(193) NOT NULL,
  `department` varchar(193) NOT NULL,
  `month` varchar(193) NOT NULL,
  `basicSalary` varchar(193) NOT NULL,
  `hourlyPay` varchar(193) NOT NULL,
  `workDays` varchar(193) NOT NULL,
  `attendancePay` varchar(193) NOT NULL,
  `overtimePay` varchar(193) NOT NULL,
  `bonus` varchar(193) NOT NULL,
  `loans` varchar(193) NOT NULL,
  `noPay` varchar(193) NOT NULL,
  `epf` varchar(193) NOT NULL,
  `totalPay` varchar(193) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `salaries`
--

INSERT INTO `salaries` (`id`, `created_at`, `updated_at`, `fullname`, `EmployeeID`, `address`, `department`, `month`, `basicSalary`, `hourlyPay`, `workDays`, `attendancePay`, `overtimePay`, `bonus`, `loans`, `noPay`, `epf`, `totalPay`) VALUES
(1, '2024-05-28 08:17:09', '2024-05-28 08:17:09', 'N. Sureka Sandaruwani', '199184203181', 'Gallegama, Ingiriya', 'hr', 'April', '39520', '190', '26', '3000', '7000', '2500', 'none', 'none', '2000', '50020'),
(2, '2024-05-28 23:56:02', '2024-05-28 23:56:02', 'Kavishka Sandaruwani', '200084704171', 'Newtown, Rathnapura', 'hr', 'April', '39520', '190', '26', '3000', '7000', '2500', 'none', 'none', '2000', '50020');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(193) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('VtN60jbDJiaKNXEntBxI4HARptaQc9GjOw0dX7cy', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYnBUTHRJTk1LaXBMR3RKRTNrSUUzYVRZeHFCekZzVFZXcWNEZFFXcyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjk6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9jb250YWN0Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1717002247);

-- --------------------------------------------------------

--
-- Table structure for table `signups`
--

CREATE TABLE `signups` (
  `username` varchar(193) NOT NULL,
  `email` varchar(193) NOT NULL,
  `password` varchar(193) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `signups`
--

INSERT INTO `signups` (`username`, `email`, `password`, `created_at`, `updated_at`) VALUES
('kavishka_20HR', 'ksandaruwani36@gmail.com', '0412', '2024-04-30 12:59:12', '2024-04-30 12:59:12'),
('Amali_12P', 'amali12@gmail.com', '4502', '2024-04-30 13:04:22', '2024-04-30 13:04:22'),
('Akila_03MO', 'akila@gmail.com', '36521', '2024-04-30 13:07:00', '2024-04-30 13:07:00'),
('janani_09HR', 'jananirasa6@gmail.com', '0909', '2024-04-30 13:10:08', '2024-04-30 13:10:08'),
('Dananjaya_26HR', 'dana123@gmail.com', '100ab', '2024-04-30 13:11:56', '2024-04-30 13:11:56'),
('Malidu_32P', 'malindu54@gmail.com', '6532ma', '2024-05-01 07:10:25', '2024-05-01 07:10:25'),
('malki_22MO', 'malkimadushani@gmail.com', '202011', '2024-05-01 07:17:26', '2024-05-01 07:17:26'),
('malshi_7P', 'malshi7@gmail.com', '3056', '2024-05-02 01:37:07', '2024-05-02 01:37:07'),
('adam', 'adam@gmail.com', '8963', '2024-05-02 01:50:21', '2024-05-02 01:50:21'),
('abc', 'abc@gmail.com', '8754', '2024-05-02 02:07:16', '2024-05-02 02:07:16'),
('diluka_10P', 'diluka2@gmail.com', '$2y$12$Mq2lli1GwnKNKTCNYa3rs.bS/Sc7gY62UmZiVShywYJOF3WujtZcO', '2024-05-28 01:48:17', '2024-05-28 01:48:17'),
('kavishka_20HR', 'ksandaruwani36@gmail.com', '$2y$12$BcZpbJS15pKB2TRWy44e7.ShWn9rBUD6O6/svZsCP0H2Nmlo6B97.', '2024-05-28 01:54:30', '2024-05-28 01:54:30'),
('Rasanjali_7HR', 'rasanjali@gmail.com', '$2y$12$MvGiEcHSCywB2ltT2yv98ufd.8IRdbpR/2hj22QsMI57LasdOdnT.', '2024-05-28 01:56:12', '2024-05-28 01:56:12'),
('Malshani_3P', 'malshani@gmail.com', '$2y$12$kKsa0C0f2NIdD9DJz80r5OtnlsUPzoHhI/UGn.zqFkoLnFwJjB9Ya', '2024-05-28 10:38:18', '2024-05-28 10:38:18'),
('Malshani_3P', 'malshani@gmail.com', '$2y$12$J9h2aHS5kyrcN45963Tk5OOIt4zh5ShRO5rHnMpkzTsghUO6cFFyO', '2024-05-28 10:38:48', '2024-05-28 10:38:48'),
('Malshani_3P', 'malshani@gmail.com', '$2y$12$mi4heriwgGTTrbNk8Npd7ug8p2JmCR9eYRK3dzylRIQa5vvonBJBa', '2024-05-28 10:39:34', '2024-05-28 10:39:34'),
('kavindu_0MO', 'kavindu@gmail.com', '$2y$12$DzJhq8vN75gSSEfGMdemm.cCxLy.6mFSP5TaFv6GULFv/foIlOIAu', '2024-05-28 10:40:26', '2024-05-28 10:40:26'),
('Latha_64MO', 'Lathaperera@gmail.com', '$2y$12$dVZ1d0jtJnCiDuNys/SS9eKw/P6p3kutS4mwvcaJPNmcn4MGYEcYW', '2024-05-28 10:42:47', '2024-05-28 10:42:47'),
('kavishka_20HR', 'ksandaruwani36@gmail.com', '$2y$12$lf1TfM0LSnml9ODqqQNC9.zvbRnpTMaJnhGewqq7SH2Bt4jfFIfVa', '2024-05-29 00:00:18', '2024-05-29 00:00:18'),
('kavishka_20HR', 'ksandaruwani36@gmail.com', '$2y$12$JD4t/VYW/ik701PGPC1NxeVhhZGp5vN5kOoCg.0QJb4Hp7L7Sp2C2', '2024-05-29 00:00:19', '2024-05-29 00:00:19');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(193) NOT NULL,
  `email` varchar(193) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(193) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oldpays`
--
ALTER TABLE `oldpays`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `salaries`
--
ALTER TABLE `salaries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `oldpays`
--
ALTER TABLE `oldpays`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `salaries`
--
ALTER TABLE `salaries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
